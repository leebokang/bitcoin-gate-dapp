import { useState } from 'react';
import { ethers } from 'ethers';
import axios from 'axios';

const gateABI = [
  "function validateBitcoinBlock(uint256, bytes calldata) public",
  "function buyCredits(uint256) public payable"
];

const gateAddress = "YOUR_DEPLOYED_GATE_ADDRESS"; // 替換為部署地址

function App() {
  const [wallet, setWallet] = useState(null);
  const [nonce, setNonce] = useState('');
  const [blockHeight, setBlockHeight] = useState('');
  const [log, setLog] = useState('');
  const [proof, setProof] = useState(null);
  let signer, gateContract;

  async function connectWallet() {
    const provider = new ethers.BrowserProvider(window.ethereum);
    await provider.send("eth_requestAccounts", []);
    signer = await provider.getSigner();
    gateContract = new ethers.Contract(gateAddress, gateABI, signer);
    setWallet(await signer.getAddress());
  }

  async function generateProof() {
    const input = { nonce: Number(nonce), hash: 88888 };
    const res = await axios.post("/api/prove", input);
    setProof(res.data.proof);
    logMessage("✅ Proof generated");
  }

  async function submitValidation() {
    if (!proof) return alert("請先生成證明");
    const provider = new ethers.BrowserProvider(window.ethereum);
    signer = await provider.getSigner();
    gateContract = new ethers.Contract(gateAddress, gateABI, signer);
    const encoded = ethers.hexlify(ethers.toUtf8Bytes(JSON.stringify(proof)));
    const tx = await gateContract.validateBitcoinBlock(blockHeight, encoded);
    await tx.wait();
    logMessage("📤 Submitted block validation");
  }

  function logMessage(msg) {
    setLog(prev => `${msg}\n` + prev);
  }

  return (
    <div style={{ padding: '20px' }}>
      <h2>🔐 BitcoinGate DApp</h2>
      <button onClick={connectWallet}>Connect Wallet</button>
      <div>{wallet}</div>

      <h3>1. Generate Proof</h3>
      <input value={nonce} onChange={e => setNonce(e.target.value)} placeholder="Enter Nonce" />
      <button onClick={generateProof}>Generate Proof</button>

      <h3>2. Submit Block Validation</h3>
      <input value={blockHeight} onChange={e => setBlockHeight(e.target.value)} placeholder="Block Height" />
      <button onClick={submitValidation}>Submit to Gate</button>

      <pre>{log}</pre>
    </div>
  );
}

export default App;
